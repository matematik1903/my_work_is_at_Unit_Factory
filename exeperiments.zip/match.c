/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   match.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: brozhko <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/09/03 11:16:47 by brozhko           #+#    #+#             */
/*   Updated: 2017/09/03 11:16:51 by brozhko          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	set_zero(int *i, int *j)
{
	*i = 0;
	*j = 0;
}

int		match(char *s1, char *s2)
{
	int i;
	int j;

	set_zero(&i, &j);
	while (s1[i] || s2[j] == '*')
	{
		if (s2[j] == '*')
		{
			while (s2[j] == '*')
				j++;
			while (s1[i] && s1[i] != s2[j])
				i++;
			while (s1[i] && !match(s1 + i, s2 + j))
			{
				i++;
				while (s1[i] && s1[i] != s2[j])
					i++;
			}
		}
		else if (s1[i++] != s2[j++])
			return (0);
	}
	if (s1[i] == s2[j])
		return (1);
	return (0);
}
