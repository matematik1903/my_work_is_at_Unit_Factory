/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Rush01.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: brozhko <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/09/03 12:31:05 by brozhko           #+#    #+#             */
/*   Updated: 2017/09/03 12:31:09 by brozhko          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */


//--------------------------------------------------------------------//


#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
//Проверка на условие валидности - выход из программы в случае ошибки.
//Рассмотрены все варианты кроме введения данных, когда судоку не складывается
int is_valid(int argc, char *argv[])
{
    int i;
    int j;
    i = 1;
    j = 0;
    if (argc < 10 || argc > 10)
    {
        write(1, "Error\n", 7);
        return (0);
    }
    while (i < argc)
    {
        while (argv[i][j] != '\0')
        { 
            if (argv[i][j] == '.' || (argv[i][j] >= '1' && argv[i][j] <= '9'))
                j++;
            else
            {
                write(1, "Error\n", 7);
                return (0);
            }
        }
        if (j != 9)
        {
            write(1, "Error\n", 7);
            return (0);
        }
        j = 0;
        i++;
    }
    return (1);
}
void    creat_start_array(char **argv, char **start_aray)
{   
    int i;
    int j;
    
    i = 0;
    j = 0;
    while (i < 9)
    {
        while (j < 9)
        {
            start_aray[i][j] = argv[i + 1][j];
            j++;
        }
        j = 0;
        i++;
    }   
}
/*int       ft_strcmp(char *s1, char *s2)
{
    int i;
    i = 0;
    while (s1[0] != '\0' || s2[0] != '\0')
    {
        if (s1[i] == '\0')
            return (s2[i]);
        if (s2[i] == '\0')
            return (s1[i]);
        if (s1[i] != s2[i])
            return (s1[i] - s2[i]);
        i++;
    }
    return (0);
}
*/
void    outputArray(char **start_aray)
{
    int i;
    int j;
    i = 0;
    j = 0;
    while (i < 9)
    {
        while (j < 9)
        {
            write(1, &start_aray[i][j], 1);
            write(1, " ", 1);
            j++;                
        }
        putchar('\n');
        j = 0;
        i++;
    }
}
/*int       search_num(char **start_aray)
{
    int i;
    int j;
    i = 0;
    j = 0;
    while (i < 9)
    {
        while (j < 9)
        {
            if (start_aray[i][j] != '.')
                j++;
            else 
                to_see_string(i, start_aray);
                to_see_column(j, start_aray);
                to_see_square(j, i, start_aray);
            j++;
        }
        j = 0;
        i++;
    }
}
//Вернет значения всех чисел, что есть в наличии, проверяя на дубли
char *to_see_string(int i, char **start_aray)
{
    int j;
    int k;
    k = 0;
    j = 0;
    char tmp [9];
    char *uses_numbers;
    uses_numbers = tmp;
    
    while (j < 9)
    {           
        if (start_aray[i][j] != '.')
        {
            if (uses_numbers[0] < '1' || uses_numbers[0] > '9')
            {
                uses_numbers[0] = start_aray[i][j];
//              k++;             
            }
            else
            {
                while (k < 9)
                {
                    if (uses_numbers[k] > '1' || uses_numbers[k] < '9')//если встретили число
                        if (uses_numbers[k] != start_aray[i][j])
                            k++;
                        if (uses_numbers[k] < '1' || uses_numbers[k] > 9)
                            uses_numbers[k] = start_aray[i][j];
                    k++;
                }
            }
        }
        j++;
    }
    return (uses_numbers);
}
*/
void        BODYA(char **argv)
{
    int i;
    int j;
    int k = 1;
    int z = 9;
    int g = 0;
    int c = 1;
    int s = 0;
    while (z != 0)
    {
        while ( s != 9)
        {
            while (c != 9)
            {
                printf("$$$");
                printf("\n");
                printf("%s\n", argv[s]);
                if ( argv[s][c] == '.' )
                {
                    char t[] = "123456789";
                    printf("%s\n", t);
                //координаты по горизонтали и вертикали
                j = 0;
                i = 0;
                int i1 = 0;
    // перевірка цисел в рядку //
                while (j < 9)
                {
                    while(i1 < 9)
                    {
                        if (argv[s][j] == t[i1])
                        {
                            t[i1] = '0';
                        } 
                        i1++;
                    }
                    i1 = 0;
                    j++;
                }
                printf("%s\n", t);
                i = 0;
                j = 0;
    // перевірка чисел в стопчику //
                while (i < 9)
                {
                    while(i1 < 9)
                    {
                        if (argv[i][c] == t[i1])
                        {
                            t[i1] = '0';
                        }
                        i1++;
                    }
                    i1 = 0;
                    i++;
                }
                  printf("%s\n", t);
      //printf("%d\n", j);
       // outputArray(argv);
    // перевірка чисел в квадратику //
   i = 0;
    j = 0;
   
   int h = 0;
   int m = 0;
    if (s > 3)
        h = 3;
    if (s >  6)
        h = 6;
    if (c > 3)
        m = 3;
    if (c >  6)
        m = 6;
    while ( i != 4 + m)
        {
            int j2 = (j % 3) + h;
            int i2 = (i % 3) + m;
            printf("%d and %d", j2, i2);
            i1 = 0;
            while(i1 < 9)
            {
                if (argv[i2][j2] == t[i1])
                    t[i1] = '0';
                i1++;
            }
            i1 = 0;
            j++;
            if ( j == 3)
            {
                j = 0;
                i++;
            }
        }
         printf("%s\n", t);
       // printf("%d\n", j);
        //    outputArray(argv);
    // підразунок допустимих фзначень //
    //
               i = 0;
                j = 0;
                while (t[i] != '\0')
                {
                    if (t[i] != '0')
                    {
                        j++;
                    }
                    i++;
                }
            
    //*/
    // якщо в даній клітинці кількість чисел 
    // яку можна записати менша чи у інших
    //
               if (j < z)
                {
                    z = j;
                }
    //
    // якщо це число дорівнює заданому нами //
    //
                if (z == k)
                {
                    g++;
                    i = 0;
                    j = 0;
                    while (t[i] != '\0')
                    {
                        if (t[i] != '0' )
                            argv[s][c] = t[i];
                        i++;
                    }
                }
    //
    // якщо кількість чисел , яку можна вписати в клітинку 
    // більша чим ми очікували
    //
              /*  if (s == 8 && c == 8)
                {
                    if ( g == 0)
                        z++;
                    else
                        z = 1;
                }
*/
               outputArray(argv);
                printf ("\n");
            }
            c++;
            
        }
        c = 0;
        s++;
    }
    z++;
    s = 0;
}

}

int main(int argc, char *argv[])
{   
    int i;
    int j;
    
    i = 0;
        
    if (is_valid(argc, argv))
    {
        char **start_aray;
        start_aray = (char **)(malloc(sizeof(char*) * 9));
        while (i < 9)
        {
            start_aray[i] = (char *)(malloc(sizeof(char) * 9));
            i++;
        }
        creat_start_array(argv, start_aray);
        outputArray (start_aray);
//      search_num (start_aray);
        BODYA(start_aray);
        
//Создаем массив на 9 элементов, куда при внесении содержимого 
//каждый раз проверим на наличие данного элемента в массиве.
//  char temp[9];
        
    }
    return (0);
}





















